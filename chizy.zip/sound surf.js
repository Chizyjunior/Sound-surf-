function playMusic(song) {
    const audioPlayer = document.getElementById('audioPlayer');
    audioPlayer.src = song;
    audioPlayer.style.display = 'block';
    audioPlayer.play();
}

function buyMusic(song) {
    alert("You've purchased " + song + "! Thank you for supporting the artist.");
    // Implement payment and download logic here
}

function uploadMusic() {
    alert("Upload functionality coming soon!");
    // Implement music upload logic here
}